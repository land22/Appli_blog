<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_e2ed99e7e70947fd0b6e8f11ad2e086b'] = 'Ähnliche Smart Blog Posts';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_00ce49ece69e4185826980f107393bb8'] = 'Es ist das funktionellste Modul des Blogs mit dem Block für ähnliche Posts für Prestashop - von smartdatasoft';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_fa214007826415a21a8456e3e09f999d'] = 'Sind Sie sich sicher, dass Sie Ihre Details löschen möchten?';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_21ee0d457c804ed84627ec8345f3c357'] = 'Einstellungen wurden erfolgreich gespeichert.';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_c54f9f209ed8fb4683e723daa4955377'] = 'Hauptparameter';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_9dfdf644519b32509c49e72a530e23c1'] = 'Die Anzahl der dargestellten ähnlichen Posts';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_e84688fd88418fd094e3df7e39963631'] = 'Ähnliche Artikel:';
