<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_d37e8c024f72eac2a69064e3263e340b'] = 'Smart Blog Recherche';
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_f40a8cf9474d456f08a0af54ac5d47ae'] = 'Le Plus Puissant Module de Recherche pour Blog de shopping Presta Shop - par smartdatasoft';
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_496d09a4b58f276873f653cbd25f8ced'] = 'Blog Recherche';
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
