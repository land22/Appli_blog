<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_da1573901cef12a84b936db2e4a45142'] = 'Archiv  Smart Blog';
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_9e5d3342fda20f4bdbe8009c8b10fb49'] = 'Es ist das funktionellste Modul des Blogs mit dem Archiv für Prestashop - von smartdatasoft';
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_fa214007826415a21a8456e3e09f999d'] = 'Sind Sie sich sicher, dass Sie Ihre Details löschen möchten?';
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_ca18b5fea5dcf5c45e7af343d97e774c'] = 'Archiv des Blogs';
