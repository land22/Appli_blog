<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_736e9c57680cf9d22827202d562899ae'] = 'Кнопка  социальных сетей  Smart Blog';
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_70bce4e1c0f15e09b66f0c2e58b97c65'] = 'Наиболее функциональный модуль блога с кнопкой социальных сетей для Prestashop - от smartdatasoft';
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_fa214007826415a21a8456e3e09f999d'] = 'Вы точно хотите удалить свои детали?';
