<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_7cf71ba7eb98833640624bc9ec63d30e'] = 'TM Header Account Block';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_3d01f28f9b86f0fe9bbb9bc3a71fce5b'] = 'Отображает информацию пользователя в шапке сайта';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Учетная запись';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Войти';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_74ecd9234b2a42ca13e775193f391833'] = 'Мои заказы';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_5973e925605a501b18e48280f04f0347'] = 'Мои возвраты';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_89080f0eedbd5491a93157930f1e45fc'] = 'Мои возвраты';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_9132bc7bac91dd4e1c453d4e96edf219'] = 'Мои кредитные квитанции';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Мои адреса';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_b4b80a59559e84e8497f746aac634674'] = 'Моя информация';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_63b1ba91576576e6cf2da6fab7617e58'] = 'Моя информация';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_95d2137c196c7f84df5753ed78f18332'] = 'Мои купоны';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_c87aacf5673fada1108c9f809d354311'] = 'Выйти';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_b357b524e740bc85b9790a0712d84a30'] = 'E-mail адрес';
$_MODULE['<{tmheaderaccount}prestashop>tmheaderaccount_dc647eb65e6711e155375218212b3964'] = 'Пароль';
