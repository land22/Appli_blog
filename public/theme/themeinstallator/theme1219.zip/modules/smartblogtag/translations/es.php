<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogtag}prestashop>smartblogtag_b84c7a512d9a3607e434c24519a97e02'] = 'Etiqueta de Smart Blog';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_a14895030612094493056c982a7089c9'] = 'Etiquetas del Más Poderoso Módulo de Blogs de Presta shop – por smartdatasoft';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_fa214007826415a21a8456e3e09f999d'] = '¿Estás seguro de querer borrar tus datos?';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_21ee0d457c804ed84627ec8345f3c357'] = 'La configuración ha sido actualizada con éxito.';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c54f9f209ed8fb4683e723daa4955377'] = 'Configuración General';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c31145c3597b3e62fe2daea13605ecac'] = 'Números de Etiquetas Mostradas';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_405f1bd6447ee27dff4b34065368dc4f'] = 'Etiquetas Publicadas';
