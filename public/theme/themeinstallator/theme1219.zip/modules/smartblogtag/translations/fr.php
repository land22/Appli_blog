<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogtag}prestashop>smartblogtag_b84c7a512d9a3607e434c24519a97e02'] = 'Smart Blog Tag';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_a14895030612094493056c982a7089c9'] = 'Le Plus Puissant Module de Tag pour Blog de shopping Presta Shop - par smartdatasoft';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_fa214007826415a21a8456e3e09f999d'] = 'Êtes-vous sûr de vouloir supprimer vos informations ?';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_21ee0d457c804ed84627ec8345f3c357'] = 'Les paramètres ont été mis à jour avec succès.';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c54f9f209ed8fb4683e723daa4955377'] = 'Paramètres Généraux';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c31145c3597b3e62fe2daea13605ecac'] = 'Nombre de Tags Affichés';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_405f1bd6447ee27dff4b34065368dc4f'] = 'Articles de Tags';
