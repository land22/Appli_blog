<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogtag}prestashop>smartblogtag_b84c7a512d9a3607e434c24519a97e02'] = 'Теги Smart Blog';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_a14895030612094493056c982a7089c9'] = 'Наиболее функциональный модуль блога с  блоком тегов для Prestashop - от smartdatasoft';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_fa214007826415a21a8456e3e09f999d'] = 'Вы точно хотите удалить свои детали?';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_21ee0d457c804ed84627ec8345f3c357'] = 'Настройки успешно сохранены.';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c54f9f209ed8fb4683e723daa4955377'] = 'Основные параметры';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c31145c3597b3e62fe2daea13605ecac'] = 'Количество отображаемых тегов';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{smartblogtag}prestashop>smartblogtag_405f1bd6447ee27dff4b34065368dc4f'] = 'Теги записей';
