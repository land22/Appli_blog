<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmproductlistgallery}prestashop>tmproductlistgallery_6f600f0fbc6372c4cdc507717cb60edb'] = 'TM Product List Gallery';
$_MODULE['<{tmproductlistgallery}prestashop>tmproductlistgallery_b199837e2b9a53d361b444a23b3e95b6'] = 'Show all images of product on product listing';
